-- AlterTable
ALTER TABLE "Profile" ALTER COLUMN "is_active" SET DEFAULT true;
